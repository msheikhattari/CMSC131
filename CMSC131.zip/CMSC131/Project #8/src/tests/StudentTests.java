package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTests {

	@Test
	public void addCustomerTest() {
		fail("Not yet implemented");
	}

}
