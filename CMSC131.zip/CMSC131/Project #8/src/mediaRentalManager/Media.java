package mediaRentalManager;

public class Media implements Comparable<Media> {
	public String title;
	public int copiesAvailable;
	
	public int compareTo(Media media) {
		if (title.compareTo(media.title) < 0) {
			return -1;
		} else if (title.compareTo(media.title) > 0) {
			return 1;
		} else {
			return 0;
		}
	}

}
