package mediaRentalManager;

public class Movie extends Media{
	public String rating;
	
	public Movie(String title, int copiesAvailable, String rating) {
		this.title = title;
		this.copiesAvailable = copiesAvailable;
		this.rating = rating;
		
	}
	
	public String toString() {
		return "Title: " + title + ", Copies Available: " + copiesAvailable + 
			   ", Rating: " + rating;
	}
	
}

