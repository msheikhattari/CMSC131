package mediaRentalManager;
import java.util.*;

public class MediaRentalManager implements MediaRentalManagerInt{
	ArrayList<Customer> customerData = new ArrayList<Customer>();
	ArrayList<Media> mediaData = new ArrayList<Media>();
	int limitedPlanLimit = 2;
	
	public void addCustomer(String name, String address, String plan) {
		Customer customer = new Customer(name, address, plan);
		customerData.add(customer);
	}
	
	public void addMovie(String title, int copiesAvailable, String rating) {
		Movie movie = new Movie(title, copiesAvailable, rating);
		mediaData.add(movie);
	}
	
	public void addAlbum(String title, int copiesAvailable, String artist, String songs) {
		Album album = new Album(title, copiesAvailable, artist, songs);
		mediaData.add(album);
	}
	
	public void setLimitedPlanLimit(int value) {
		limitedPlanLimit = value;
	}
	
	public String getAllCustomersInfo() {
		StringBuffer info = new StringBuffer("***** Customers' Information *****");
		int i;
		
		Collections.sort(customerData);
		for(i = 0; i < customerData.size(); i++) {
			info.append("\nName: " + customerData.get(i).name + ", Address: " + 
					    customerData.get(i).address + ", Plan: " + customerData.get(i).plan
					    + "\nRented: " + customerData.get(i).rented + "\nQueue: " + 
					    customerData.get(i).queue);
		}
		return info.toString();
	}

	public String getAllMediaInfo() {
		StringBuffer info = new StringBuffer("***** Media Information *****");
		int i;
		
		Collections.sort(mediaData);
		for(i = 0; i < mediaData.size(); i++) {
			info.append(mediaData.get(i).toString());
		}
		return info.toString();
	}
	
	public boolean addToQueue(String customerName, String mediaTitle) {
		int i, j;
		
		for(i = 0; i < customerData.size(); i++) {
			if(customerData.get(i).name == customerName) {
				for(j = 0; j < customerData.get(i).queue.size(); j++) {
					if(customerData.get(i).queue.get(j).equals(mediaTitle)) {
						return false;
					}
				}
				customerData.get(i).queue.add(mediaTitle);
				return true;
			}
		}
		return false;
	}
	
	public boolean removeFromQueue(String customerName, String mediaTitle) {
		int i, j;
		
		for(i = 0; i < customerData.size(); i++) {
			if(customerData.get(i).name == customerName) {
				for(j = 0; j < customerData.get(i).queue.size(); j++) {
					if(customerData.get(i).queue.get(j).equals(mediaTitle)) {
						customerData.get(i).queue.remove(j);
						return true;
					}
				}
			}
		}
		return false;
	}

	public String processRequests() {
		int i, j, k;
		StringBuffer processMessage = new StringBuffer();
		Collections.sort(customerData);
		
		for(i = 0; i < customerData.size(); i++) {
			for(j = 0; j < customerData.get(i).queue.size(); j++) {
				if(customerData.get(i).plan.equals("UNLIMITED") ||
					customerData.get(i).rented.size() < limitedPlanLimit){
					for(k = 0; k < mediaData.size(); k++) {
						if(customerData.get(i).queue.get(j).equals(mediaData.get(k).title) 
						   && mediaData.get(k).copiesAvailable > 0) {
							mediaData.get(k).copiesAvailable--;
							customerData.get(i).rented.add(customerData.get(i).queue.get(j));
							processMessage.append("Sending " + mediaData.get(k).title
									              + " to " + customerData.get(i).name + "\n");
						}
					}
				}
			}
			for(j = 0; j < customerData.get(i).rented.size(); j++) {
				for(k = 0; k < customerData.get(i).queue.size(); k++) {
					if(customerData.get(i).rented.get(j).equals(customerData.get(i).queue.get(k))) {
						customerData.get(i).queue.remove(k);
					}
				}
			}
		}
		return processMessage.toString();
	}
	
	public boolean returnMedia(String customerName, String mediaTitle) {
		int i, j, k;
		
		for(i = 0; i < customerData.size(); i++) {
			if(customerData.get(i).name == customerName) {
				for(j = 0; j < customerData.get(i).rented.size(); j++) {
					if(customerData.get(i).rented.get(j).equals(mediaTitle)) {
						customerData.get(i).rented.remove(j);
						for(k = 0; k < mediaData.size(); k++) {
							if(mediaData.get(k).title == mediaTitle) {
								mediaData.get(k).copiesAvailable++;
							}
						}
						return true;
					}
				}
			}
		}
		return true;
	}
	
	public ArrayList<String> searchMedia(String title, String rating, String artist, String songs){
		int i;
		ArrayList<String> searchResult = new ArrayList<String>();
		
		if(title != null && rating != null && artist != null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title && movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title && album.artist == artist && album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title == null && rating != null && artist != null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.artist == artist && album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title == null && rating == null && artist != null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.artist == artist && album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title == null && rating == null && artist == null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title == null && rating == null && artist == null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					searchResult.add(mediaData.get(i).title);
				}else if(mediaData.get(i) instanceof Album) {
						searchResult.add(mediaData.get(i).title);
					
				}
			}
		}else if(title != null && rating != null && artist != null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title && movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title && album.artist == artist) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title != null && rating != null && artist == null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title && movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title != null && rating == null && artist == null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title == null && rating != null && artist != null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.artist == artist) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title == null && rating != null && artist == null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}
			}
		}else if(title == null && rating == null && artist != null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {

				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.artist == artist) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title != null && rating == null && artist == null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title && album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title != null && rating == null && artist != null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title && album.artist == artist && album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title != null && rating != null && artist == null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title && movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title && album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title != null && rating == null && artist != null && songs == null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.title == title) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.title == title && album.artist == artist) {
						searchResult.add(album.title);
					}
				}
			}
		}else if(title == null && rating != null && artist == null && songs != null) {
			for(i = 0; i < mediaData.size(); i++) {
				if(mediaData.get(i) instanceof Movie) {
					Movie movie = (Movie) mediaData.get(i);
					if(movie.rating == rating) {
						searchResult.add(movie.title);
					}
				}else if(mediaData.get(i) instanceof Album) {
					Album album = (Album) mediaData.get(i);
					if(album.songs.contains(songs)) {
						searchResult.add(album.title);
					}
				}
			}
		}
		Collections.sort(searchResult);
		return searchResult;
	}

}
