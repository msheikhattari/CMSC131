package mediaRentalManager;

public class Album extends Media{
	public String artist;
	public String songs;
	
	public Album(String title, int copiesAvailable, String artist, String songs) {
		this.title = title;
		this.copiesAvailable = copiesAvailable;
		this.artist = artist;
		this.songs = songs;
	}
	
	public String toString() {
		return "Title: " + title + ", Copies Available: " + copiesAvailable + 
			   ", Artist: " + artist + ", Songs: " + songs;
	}
}
