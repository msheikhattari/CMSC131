package mediaRentalManager;

import java.util.ArrayList;

public class Customer implements Comparable<Customer>{
	public String name, address, plan;
	ArrayList<String> rented = new ArrayList<String>();
	ArrayList<String> queue = new ArrayList<String>();

	
	public Customer(String name, String address, String plan) {
		this.name = name;
		this.address = address;
		this.plan = plan;
	}
	
	public int compareTo(Customer customer) {
		if (name.compareTo(customer.name) < 0) {
			return -1;
		} else if (name.compareTo(customer.name) > 0) {
			return 1;
		} else {
			return 0;
		}
	}

}
