package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import programs.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {

	@Test
	public void getArrayStringTest() {
		int[] array = { 1, 2 };
		int[] emptyArray = {};
		char separator = ',';

		System.out.println(Utilities.getArrayString(array, separator));

		assertEquals(Utilities.getArrayString(array, separator), "1,2");
		assertEquals(Utilities.getArrayString(emptyArray, separator), "");
	}

	@Test
	public void getInstancesTest() {
		int[] array = { 1, 2, 3, 4, 5 };

		System.out.println(Utilities.getInstances(array, 2, 4));

		assertEquals(Utilities.getInstances(array, 2, 4), 3);
	}

	@Test
	public void filterTest() {
		int[] array = { 1, 2, 3, 4, 5 };
		int[] newArray = Utilities.filter(array, 2, 4);
		int[] expectedArray = { 2, 3, 4 };

		System.out.println(Utilities.getArrayString(newArray, ','));

		assertEquals(Utilities.getArrayString(newArray, ','),
				     Utilities.getArrayString(expectedArray, ','));
	}

	@Test
	public void rotateTest() {
		int[] array1 = { 1, 2, 3, 4, 5 };
		int[] array2 = { 1, 2, 3, 4, 5 };
		int[] array3 = { 1, 2 };
		int[] expected1 = { 3, 4, 5, 1, 2 };
		int[] expected2 = { 4, 5, 1, 2, 3 };
		int[] expected3 = { 2, 1 };

		Utilities.rotate(array1, true, 2);
		Utilities.rotate(array2, false, 2);
		Utilities.rotate(array3, true, 3);

		System.out.println(Utilities.getArrayString(array1, ','));
		System.out.println(Utilities.getArrayString(array2, ','));
		System.out.println(Utilities.getArrayString(array3, ','));

		assertEquals(Utilities.getArrayString(array1, ','), 
				     Utilities.getArrayString(expected1, ','));
		assertEquals(Utilities.getArrayString(array2, ','), 
				     Utilities.getArrayString(expected2, ','));
		assertEquals(Utilities.getArrayString(array3, ','), 
				     Utilities.getArrayString(expected3, ','));
	}

	@Test
	public void getArrayStringsLongerThanTest() {
		StringBuffer[] array1 = { new StringBuffer("Ham"), new StringBuffer("Jimmy") };
		StringBuffer[] array2 = Utilities.getArrayStringsLongerThan(array1, 3);

		System.out.println(array2[0]);

		assertEquals(array2[0].toString(), array1[1].toString());
		assertFalse(array2[0] == array1[1]);
	}

	@Test
	public void countInstancesOfTest() {
		int[] jeff = { 2, 2, 3, 3, 5 };

		System.out.println(Utilities.countInstancesOf(3, jeff));

		assertEquals(Utilities.countInstancesOf(3, jeff), 2);
	}

	@Test
	public void hasTwoInstancesOfAnyValueTest() {
		int[] array1 = { 1, 2, 1, 2, 5 };
		int[] array2 = { 1, 1, 1, 3, 4 };
		int[] array3 = { 1, 0, 2, 3, 4 };

		boolean b = Utilities.hasTwoInstancesOfAnyValue(array1);
		boolean c = Utilities.hasTwoInstancesOfAnyValue(array2);
		boolean d = Utilities.hasTwoInstancesOfAnyValue(array3);

		System.out.println(b);
		System.out.println(c);
		System.out.println(d);

		assertTrue(b);
		assertFalse(c);
		assertFalse(d);
	}

	@Test
	public void hasTwoPairsOfDifferentValuesTest() {
		int[] array1 = { 2, 2, 2, 2, 5 };
		int[] array2 = { 2, 2, 1, 1, 5 };
		int[] array3 = { 0, 1, 2, 3, 5 };

		boolean b = Utilities.hasTwoPairsOfDifferentValues(array1);
		boolean c = Utilities.hasTwoPairsOfDifferentValues(array2);
		boolean d = Utilities.hasTwoPairsOfDifferentValues(array3);

		System.out.println(b);
		System.out.println(c);
		System.out.println(d);

		assertFalse(b);
		assertTrue(c);
		assertFalse(d);
	}

	@Test
	public void isIncreasingTest() {
		int[] array1 = { 2, 2, 2, 2, 3 };
		int[] array2 = { 1, 2, 3, 2 };

		boolean b = Utilities.isIncreasing(array1);
		boolean c = Utilities.isIncreasing(array2);

		System.out.println(b);
		System.out.println(c);

		assertTrue(b);
		assertFalse(c);

	}

	@Test
	public void getIndicesTest() {
		int[] array = { 2, 2, 2, 2, 1 };

		int[] indices1 = Utilities.getIndices(array, false);
		int[] indices2 = Utilities.getIndices(array, true);

		int[] expected1 = { 4 };
		int[] expected2 = { 0, 1, 2, 3 };

		System.out.println(Utilities.getArrayString(indices1, ','));
		System.out.println(Utilities.getArrayString(indices2, ','));

		assertEquals(Utilities.getArrayString(indices1, ','), 
				     Utilities.getArrayString(expected1, ','));
		assertEquals(Utilities.getArrayString(indices2, ','),
				     Utilities.getArrayString(expected2, ','));
	}
}
