package programs;

public class Utilities {
	/**
	 * Returns a string where each array entry (except the last one) is followed by
	 * the specified separator. An empty string will be returned if the array has no
	 * elements. An IllegalArgumentException (with any message) will be thrown when
	 * the array parameter is null.
	 * 
	 * @param array
	 * @param separator
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @return string
	 */
	public static String getArrayString(int[] array, char separator) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		} else if (array.length == 0) {
			return "";
		}

		int i;
		StringBuffer arrayBuffer = new StringBuffer();

		arrayBuffer.append(array[0]);
		for (i = 1; i < array.length; i++) {
			arrayBuffer.append(separator);
			arrayBuffer.append(array[i]);
		}

		return new String(arrayBuffer);
	}

	/**
	 * Returns the number of values that are in the range defined by lowerLimit
	 * (inclusive) and upperLimit (inclusive). An IllegalArgumentException (with any
	 * message) will be thrown when the array parameter is null or if lowerLimit is
	 * greater than upperLimit.
	 * 
	 * @param array
	 * @param lowerLimit
	 * @param upperLimit
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @throws IllegalArgumentException When lowerLimit is greater than upperLimit.
	 * @return number of values in range
	 */
	public static int getInstances(int[] array, int lowerLimit, int upperLimit) {
		int i, j = 0;
		if (array == null || lowerLimit > upperLimit) {
			throw new IllegalArgumentException("STOP BRO");
		}

		for (i = 0; i < array.length; i++) {
			if (array[i] <= upperLimit && array[i] >= lowerLimit) {
				j++;
			}
		}

		return j;
	}

	/**
	 * Returns a new array with values in the array that exists in the range defined
	 * by lowerLimit (inclusive) and upperLimit (inclusive). An
	 * IllegalArgumentException (with any message) will be thrown when the array
	 * parameter is null or if lowerLimit is greater than upperLimit.
	 * 
	 * @param array
	 * @param lowerLimit
	 * @param upperLimit
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @throws IllegalArgumentException When lowerLimit is greater than upperLimit.
	 * @return array with values in range.
	 */
	public static int[] filter(int[] array, int lowerLimit, int upperLimit) {
		if (array == null || lowerLimit > upperLimit) {
			throw new IllegalArgumentException("STOP BRO");
		}
		int i, j = getInstances(array, lowerLimit, upperLimit);

		int[] newArray = new int[j];
		j = 0;

		for (i = 0; i < array.length; i++) {
			if (array[i] <= upperLimit && array[i] >= lowerLimit) {
				newArray[j] = array[i];
				j++;
			}
		}

		return newArray;
	}

	/**
	 * Rotates the provided array left if leftRotation is true; right otherwise. The
	 * number of positions to rotate is determined by the positions parameter. For
	 * example, rotating the array 10, 20, 7, 8 two positions to the left will
	 * update the array to 7, 8, 10, 20. Only arrays with 2 or more elements will be
	 * rotated, therefore no rotation will take place for an array of size 1 or 0.
	 * An IllegalArgumentException (with any message) will be thrown when the array
	 * parameter is null or positions is a negative value.
	 * 
	 * Hint: adding private methods that rotate an array one position to the left
	 * and one position to the right can help.
	 * 
	 * @param array
	 * @param leftRotation
	 * @param positions
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @throws IllegalArgumentException When positions is negative.
	 */
	public static void rotate(int[] array, boolean leftRotation, int positions) {
		if (array == null || positions < 0) {
			throw new IllegalArgumentException("STOP BRO");
		} else if (array.length < 2) {
			return;
		}

		int i, j = 0;
		int[] newArray = new int[array.length];

		if (array.length < positions) {
			int q = positions / array.length;
			positions = positions - q * array.length;
		}

		if (leftRotation == true) {
			for (i = positions; i < array.length; i++, j++) {
				newArray[j] = array[i];
			}
			for (i = 0; i < positions; i++, j++) {
				newArray[j] = array[i];
			}
		} else {
			for (i = array.length - positions; i < array.length; i++, j++) {
				newArray[j] = array[i];
			}
			for (i = 0; i < array.length - positions; i++, j++) {
				newArray[j] = array[i];
			}
		}

		for (i = 0; i < array.length; i++) {
			array[i] = newArray[i];
		}

		array = newArray;
	}

	/**
	 * Returns a StringBuffer array with COPIES of StringBuffer objects present in
	 * the array parameter with a length greater than the length parameter. If no
	 * StringBuffer object is found an empty array will be returned. An
	 * IllegalArgumentException (with any message) will be thrown when the array
	 * parameter is null.
	 * 
	 * @param array
	 * @param length
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @return
	 */
	public static StringBuffer[] getArrayStringsLongerThan(StringBuffer[] array, 
														   int length) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		}

		int i, j = 0;

		for (i = 0; i < array.length; i++) {
			if (array[i].length() > length) {
				j++;
			}
		}

		if (j == 0) {
			StringBuffer[] newArray = new StringBuffer[0];
			return newArray;
		}

		StringBuffer[] newArray = new StringBuffer[j];
		j = 0;

		for (i = 0; i < array.length; i++) {
			if (array[i].length() > length) {
				newArray[j] = new StringBuffer(array[i]);
			}
		}

		return newArray;
	}

	/**
	 * Returns the number of instances of the value parameter (if any) in the array.
	 * An IllegalArgumentException (with any message) will be thrown when the array
	 * parameter is null.
	 * 
	 * @paran value
	 * @param array
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @return
	 */
	public static int countInstancesOf(int value, int[] array) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		}

		int i, j = 0;

		for (i = 0; i < array.length; i++) {
			if (array[i] == value) {
				j++;
			}
		}
		return j;
	}

	/**
	 * Returns true if the array has exactly 2 instances of any value. For example,
	 * 4, 5, 89, 5, 7 has 2 instances of 5. There could be more than one value with
	 * 2 instances. An IllegalArgumentException (with any message) will be thrown
	 * when the array parameter is null.
	 * 
	 * @param array
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @return True if two instances found; false otherwise.
	 */
	public static boolean hasTwoInstancesOfAnyValue(int[] array) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		}
		int i, j, k;

		for (i = 0; i < array.length; i++) {
			k = 0;
			for (j = i + 1; j < array.length; j++) {
				if (array[i] == array[j]) {
					k++;
				}
			}
			if (k == 1) {
				return true;
			} else if (k > 1) {
				return false;
			}
		}

		return false;
	}

	/**
	 * Returns true if the array has at least two pairs of numbers where each pair
	 * has the same values and the number in a pair does not appear in any other
	 * pair. For example, 6, 8, 6, 3, 2, 3, 8, 1, 8, 8 has the pairs (6, 6), (3, 3).
	 * For the numbers 3, 3, 3, 3, 3, 3 there are no pairs. An
	 * IllegalArgumentException (with any message) will be thrown when the array
	 * parameter is null.
	 * 
	 * @param array
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @return True if at least two pairs found; false otherwise.
	 */
	public static boolean hasTwoPairsOfDifferentValues(int[] array) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		}
		int i, j, k, l = 0, m = 0;

		for (i = 0; i < array.length; i++) {
			k = 0;
			for (j = i + 1; j < array.length; j++) {
				if (array[i] == array[j]) {
					k++;
				}
			}
			if (k == 1) {
				l++;
			} else if (k >= 3) {
				m++;
			}
		}

		if (l >= 2 && m == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Determines whether elements of an array are increasing. By definition an
	 * array of 0 or 1 elements is increasing. For example, the array -40, 30, 30,
	 * 50 is increasing; the array 10, 5, 20 is not increasing. An
	 * IllegalArgumentException (with any message) will be thrown when the array
	 * parameter is null.
	 * 
	 * @param array
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @return True if increasing; false otherwise.
	 */
	public static boolean isIncreasing(int[] array) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		} else if (array.length < 2) {
			return true;
		}
		int i;

		for (i = 0; i < array.length - 1; i++) {
			if (array[i] > array[i + 1]) {
				return false;
			}
		}

		return true;

	}

	/**
	 * Returns an array with the indices of even values in the array parameter, if
	 * the even parameter is true; otherwise the array will have indices of odd
	 * values in the array parameter. For example, for the array 10, 5, 8, 19, the
	 * method will return an array of size 2 with the values 0, 2. The returned
	 * array must have a size that corresponds to the number of even or odd values
	 * present in the array parameter. An IllegalArgumentException (with any
	 * message) will be thrown when the array parameter is null.
	 * 
	 * @param array
	 * @throws IllegalArgumentException When a null array parameter is provided.
	 * @param array
	 * @param even
	 * @return
	 */
	public static int[] getIndices(int[] array, boolean even) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		}
		int i, j = 0, m = 0;

		if (even == true) {
			for (i = 0; i < array.length; i++) {
				if (array[i] % 2 == 0) {
					m++;
				}
			}
			int[] indicesArray = new int[m];

			for (i = 0; i < array.length; i++) {
				if (array[i] % 2 == 0) {
					indicesArray[j] = i;
					j++;
				}
			}
			return indicesArray;
		} else {
			for (i = 0; i < array.length; i++) {
				if (array[i] % 2 == 1) {
					m++;
				}
			}
			int[] indicesArray = new int[m];

			for (i = 0; i < array.length; i++) {
				if (array[i] % 2 == 1) {
					indicesArray[j] = i;
					j++;
				}
			}
			return indicesArray;
		}

	}
}