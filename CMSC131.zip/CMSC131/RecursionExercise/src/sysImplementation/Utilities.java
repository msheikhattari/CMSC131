package sysImplementation;

import java.util.ArrayList;

public class Utilities {

	public static String addDelimiter(String str, char delimeter) {		
		if(str.length() == 1) {
			return str;
		}else {
			return Character.toString(str.charAt(0)) + Character.toString(delimeter)
				   + addDelimiter(str.substring(1), delimeter);
		}
	}

	public static String getDigits(String str) {
		if(str.length() == 1 && Character.isDigit(str.charAt(0))) {
			return str;
		}else if(str.length() == 1 && !Character.isDigit(str.charAt(0))) {
			return "";
		}else if(str.length() > 1 && Character.isDigit(str.charAt(0))) {
			return Character.toString(str.charAt(0)) + getDigits(str.substring(1));
		}else {
			return getDigits(str.substring(1));
		}
	}

	public static void replaceCharacter(char[] array, char target, char replacement) {
		cleverReplace(array, target, replacement, 0);
	}

	public static int getSumEven(int[] array) {
		return cleverSum(array, 0);
	}

	public static ArrayList<Integer> getListRowIndices(int[][] array, int rowLength) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		return cleverRowIndices(array, rowLength, list, 0);
	}

	public static int replaceCells(char[][] array, int x, int y, char target, char replacement) {
		return cleverCells(array, x, y, target, replacement, new int[][]{{0,0},{0,0}}, 0);
	}
	
	private static int cleverSum(int[] array, int counter) {
		if(counter == array.length) {
			return 0;
		}else if(array[counter] %2 == 1) {
			counter = counter + 1;
			return cleverSum(array, counter);
		}else {
			counter = counter + 1;
			return array[counter - 1] + cleverSum(array, counter);
		}
	}
	private static void cleverReplace(char[] array, char target, char replacement,
									  int counter) {
		if(counter == array.length) {
			return;
		}else if(array[counter] == target) {
			array[counter] = replacement;
			counter = counter + 1;
			cleverReplace(array, target, replacement, counter);
		}else {
			counter = counter + 1;
			cleverReplace(array, target, replacement, counter);
		}
	}
	private static ArrayList<Integer> cleverRowIndices(int[][] array, int rowLength, 
											ArrayList<Integer> list, int counter) {
		if(counter == array.length) {
			return list;
		}else if(array[counter].length == rowLength) {
			list.add(counter);
			counter = counter + 1;
			return cleverRowIndices(array, rowLength, list, counter);
		}else {
			counter = counter + 1;
			return cleverRowIndices(array, rowLength, list, counter);
		}
	}
	private static int cleverCells(char[][] array, int x, int y, char target, 
								   char replacement, int[][] coords, int counter) {
		coords = new int[][]{{x , y}, {x - 1, y - 1}, {x - 1, y}, {x - 1, y + 1}, 
			{x, y + 1}, {x + 1, y + 1}, {x + 1, y}, {x + 1, y -1}, {x, y - 1}};
							  
		if(counter == 9) {
			return 0;
		}else if(!isValidXY(array, coords[counter])) {
			counter = counter + 1;
			return cleverCells(array, x, y, target, replacement, coords, counter);
		}else {
			if(array[coords[counter][0]][coords[counter][1]] == target) {
				array[coords[counter][0]][coords[counter][1]] = replacement;
				if(counter > 0) {
					int[][] temp= new int[][]{{coords[counter][0] , coords[counter][1]}, 
						{coords[counter][0] - 1, coords[counter][1] - 1}, 
						{coords[counter][0] - 1, coords[counter][1]},
						{coords[counter][0] - 1, coords[counter][1] + 1}, 
						{coords[counter][0], coords[counter][1] + 1}, 
						{coords[counter][0] + 1, coords[counter][1] + 1}, 
						{coords[counter][0] + 1, coords[counter][1]}, 
						{coords[counter][0] + 1, coords[counter][1] -1}, 
						{coords[counter][0], coords[counter][1] - 1}};
						counter = counter + 1;
					return 1 + cleverCells(array, coords[counter - 1][0], coords[counter - 1][1],
										   target, replacement, temp, 1) +  
					cleverCells(array, x, y, target, replacement, coords, counter);
				}else {
					counter = counter + 1;
					return 1 + cleverCells(array, x, y, target, replacement, coords, counter);
				}
			}else {
				counter = counter + 1;
				return cleverCells(array, x, y, target, replacement, coords, counter);
			}
		}
		
	}
	
	private static boolean isValidXY(char[][]array, int[] coord) {
		if(coord[0] >= 0&& coord[1] >= 0 && array.length > coord[0] &&
		   array[coord[0]].length > coord[1]) {
			return true;
		}else {
			return false;
		}
	}
}
