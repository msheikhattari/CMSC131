package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import sysImplementation.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING) 
public class StudentTests {
	
	@Test
	public void addDelimiterTest() {
		String test = "C";
		System.out.println(Utilities.addDelimiter(test, ','));
	}
	
	@Test
	public void getDigitsTest() {
		String test = "C123at456";
		System.out.println(Utilities.getDigits(test));
	}
	
	@Test
	public void getSumEvenTest() {
		int[] test = {1, 2, 3, 4, 5, 6};
		System.out.println(Utilities.getSumEven(test));
	}
	
	@Test
	public void replaceCharacterTest() {
		char[] test = {'a', '.', 'c', '.', '.', 'd'};
		Utilities.replaceCharacter(test, '.', '*');
	}
	
	@Test
	public void getListRowIndicesTest() {
		int[][] test = {{1,2}, {3, 4, 5}, {6 , 7}, {8, 9}, {10, 11, 12}};
		System.out.println(Utilities.getListRowIndices(test, 2));
	}
	
	@Test
	public void replaceCellsTest() {
		char[][] charArray = {
	              {'R', 'Y', 'R', 'Y', 'Y'},
	              {'R', 'Y', 'R', 'Y', 'Y'},
	              {'R', 'M', 'R', 'Y', 'Y'},
	              {'R', 'Y', 'Y', 'Y', 'Y'},
	              {'R', 'Y', 'R', 'Y', 'Y'},
	              {'R', 'Y', 'R', 'Y', 'P'},
};
		System.out.println(Utilities.replaceCells(charArray, 1, 3, 'Y', '*'));
	}

}