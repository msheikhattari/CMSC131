package programs;

import java.util.Scanner;

public class ColorGenerator {

	public static void main(String[] args) {
		String red, greenBlue, finalColor;
		finalColor = "#";
		Scanner scanner = new Scanner(System.in);
		System.out.print("Do you want red? (Yes/Yeah/No): ");
		red = scanner.next();

		if (red.equals("Yes") || red.equals("Yeah")){
			finalColor += "FF";
		} else {
			finalColor += "00";
		}

		System.out.print("Do you want green and blue? (Yes/Yeah/No): ");
		greenBlue = scanner.next();

		if (greenBlue.equals("Yes") || greenBlue.equals("Yeah")) {
			finalColor += "FFFF";
		} else {
			finalColor += "0000";
		}

		System.out.println("Final Color: " + finalColor);
		scanner.close();

	}
}