package programs;
import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int height, width;
		double area;
		
		System.out.print("Enter base: ");
		height = scanner.nextInt();
		
		System.out.print("Enter height: ");
		width = scanner.nextInt();
		
		area = height * width * 0.5 ;
		System.out.println("Area is: " + area);

		scanner.close();
	}
}