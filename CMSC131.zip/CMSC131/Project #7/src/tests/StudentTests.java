package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTests {

	@Test
	public void appendLeftRighttest() {
		char[][] a = { { 'a', 'b' }, { 'd' } };
		char[][] b = { { 'c', }, { 'e', 'f' } };
		char[][] c = system.TwoDimArrayUtil.appendLeftRight(a, b);

		// left has more rows than right:

		char[][] d = { { 'a', 'b' }, { 'd' } };
		char[][] e = { { 'c' } };
		char[][] f = system.TwoDimArrayUtil.appendLeftRight(d, e);

		// right has more rows than left:

		char[][] g = { { 'a', 'b' } };
		char[][] h = { { 'c' }, { 'd' } };
		char[][] i = system.TwoDimArrayUtil.appendLeftRight(g, h);

	}

	@Test
	public void appendTopBottomTest() {
		char[][] a = { { 'a', 'b' }, { 'd' } };
		char[][] b = { { 'c', }, { 'e', 'f' } };
		char[][] c = system.TwoDimArrayUtil.appendTopBottom(a, b);

		// left has more rows than right:

		char[][] d = { { 'a', 'b' }, { 'd' } };
		char[][] e = { { 'c' } };
		char[][] f = system.TwoDimArrayUtil.appendTopBottom(d, e);

		// right has more rows than left:

		char[][] g = { { 'a', 'b' } };
		char[][] h = { { 'c' }, { 'd' } };
		char[][] i = system.TwoDimArrayUtil.appendTopBottom(g, h);

	}

	@Test
	public void isRaggedTest() {
		char[][] a = { { 'a', 'b' }, { 'd' } };
		char[][] b = { { 'a', 'b' }, { 'c', 'd' } };
		system.TwoDimArrayUtil.isRagged(a);
		system.TwoDimArrayUtil.isRagged(b);

	}

	@Test
	public void rotateLeftOneColumnTest() {
		char[][] a = { { 'a', 'b' }, { 'd' } };
		char[][] b = { { 'a', 'b' }, { 'c', 'd' } };
		char[][] c = { { 'a', 'b', 'c' }, { 'd', 'e', 'f' }, { 'g', 'h', 'i' } };
		// system.TwoDimArrayUtil.rotateLeftOneColumn(a);
		system.TwoDimArrayUtil.rotateLeftOneColumn(b);
		system.TwoDimArrayUtil.rotateLeftOneColumn(c);

	}

	@Test
	public void rotateTopOneRowTest() {
		char[][] a = { { 'a', 'b' } };
		char[][] b = { { 'a', 'b' }, { 'c', 'd' } };
		char[][] c = { { 'a', 'b', 'c' }, { 'd', 'e', 'f' }, { 'g', 'h', 'i' } };
		system.TwoDimArrayUtil.rotateTopOneRow(a);
		system.TwoDimArrayUtil.rotateTopOneRow(b);
		system.TwoDimArrayUtil.rotateTopOneRow(c);

	}

}
