package system;

public class CombineTopBottom implements Diagram {

	int animationType;
	char[][] board;

	public char[][] getBoard() {
		return board;

	}

	public char[][] nextAnimationStep() {
		if (animationType == 1) {
			system.TwoDimArrayUtil.rotateLeftOneColumn(board);
		} else if (animationType == 2) {
			system.TwoDimArrayUtil.rotateTopOneRow(board);
		}
		return board;
	}

	public int getNumberRows() {
		return board.length;

	}

	public int getNumberCols() {
		return board[0].length;

	}

	public CombineTopBottom(Diagram top, Diagram bottom, int animationType) {
		this.animationType = animationType;
		board = system.TwoDimArrayUtil.appendTopBottom(top.getBoard(), bottom.getBoard());
	}

}
