package system;

public class TwoDimArrayUtil {
	public static char[][] appendLeftRight(char[][] left, char[][] right) {
		if (left == null || right == null) {
			throw new IllegalArgumentException("STOP BRO");
		}

		int row, column, totalLength, totalCols;

		if (left.length > right.length) {
			totalLength = left.length;
		} else {
			totalLength = right.length;
		}

		char[][] newArray = new char[totalLength][];

		for (row = 0; row < totalLength; row++) {
			if (row < left.length && row < right.length) {
				totalCols = left[row].length + right[row].length;
				newArray[row] = new char[totalCols];

				for (column = 0; column < totalCols; column++) {
					if (column < left[row].length) {
						newArray[row][column] = left[row][column];
					} else {
						newArray[row][column] = right[row][column - left[row].length];
					}
				}
			} else if (row >= left.length) {
				newArray[row] = new char[right[row].length];

				for (column = 0; column < right[row].length; column++) {
					newArray[row][column] = right[row][column];
				}
			} else if (row >= right.length) {
				newArray[row] = new char[left[row].length];

				for (column = 0; column < left[row].length; column++) {
					newArray[row][column] = left[row][column];
				}
			}

		}
		return newArray;
	}

	public static char[][] appendTopBottom(char[][] top, char[][] bottom) {
		if (top == null || bottom == null) {
			throw new IllegalArgumentException("STOP BRO");
		}

		int row, column, totalLength = top.length + bottom.length;

		char[][] newArray = new char[totalLength][];

		for (row = 0; row < totalLength; row++) {
			if (row < top.length) {
				newArray[row] = new char[top[row].length];
				for (column = 0; column < top[row].length; column++) {
					newArray[row][column] = top[row][column];
				}
			} else {
				newArray[row] = new char[bottom[row - top.length].length];
				for (column = 0; column < bottom[row - top.length].length; column++) {
					newArray[row][column] = bottom[row - top.length][column];
				}
			}
		}
		return newArray;
	}

	public static boolean isRagged(char[][] array) {
		if (array == null) {
			throw new IllegalArgumentException("STOP BRO");
		}

		int row;

		for (row = 1; row < array.length; row++) {
			if (array[row].length != array[row - 1].length) {
				return true;
			}
		}
		return false;
	}

	public static void rotateLeftOneColumn(char[][] array) {
		if (array == null || isRagged(array)) {
			throw new IllegalArgumentException("STOP BRO");
		}

		int row, column;
		char firstCol;

		for (row = 0; row < array.length; row++) {
			if (array[row].length > 1) {
				firstCol = array[row][0];
				for (column = 1; column < array[row].length; column++) {
					array[row][column - 1] = array[row][column];
				}
				array[row][array[row].length - 1] = firstCol;
			}
		}
	}

	public static void rotateTopOneRow(char[][] array) {
		if (array == null || isRagged(array)) {
			throw new IllegalArgumentException("STOP BRO");
		} else if (array.length == 1) {
			return;
		}

		int row, column;
		char[] firstRow = new char[array[0].length];

		for (column = 0; column < array[0].length; column++) {
			firstRow[column] = array[0][column];
		}

		for (row = 0; row < array.length - 1; row++) {
			for (column = 0; column < array[row].length; column++) {
				array[row][column] = array[row + 1][column];
			}
		}
		for (column = 0; column < array[0].length; column++) {
			array[array.length - 1][column] = firstRow[column];
		}
	}
}
