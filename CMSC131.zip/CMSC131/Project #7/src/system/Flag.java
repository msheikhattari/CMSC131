package system;

public class Flag implements Diagram{

	int animationType;
	char[][] board;

	public char[][] getBoard() {
		return board;

	}

	public char[][] nextAnimationStep() {
		if (animationType == 1) {
			system.TwoDimArrayUtil.rotateLeftOneColumn(board);
		} else if (animationType == 2) {
			system.TwoDimArrayUtil.rotateTopOneRow(board);
		}
		return board;
	}

	public int getNumberRows() {
		return board.length;

	}

	public int getNumberCols() {
		return board[0].length;

	}

	public Flag(int size, char color1, char color2, char color3,
			int animationType) {
		this.animationType = animationType;
		String diagram = app.DrawingApp.getFlag(size, color1, color2, color3);
		board = gui.BoardCell.getCharArray(diagram);
	}

}
