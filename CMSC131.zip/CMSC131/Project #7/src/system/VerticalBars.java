package system;

public class VerticalBars implements Diagram {

	int animationType;
	char[][] board;

	public char[][] getBoard() {
		return board;

	}

	public char[][] nextAnimationStep() {
		if (animationType == 1) {
			system.TwoDimArrayUtil.rotateLeftOneColumn(board);
		}
		return board;
	}

	public int getNumberRows() {
		return board.length;

	}

	public int getNumberCols() {
		return board[0].length;

	}

	public VerticalBars(int maxRows, int maxCols, int bars, char color1, char color2,
						char color3, int animationType) {
		this.animationType = animationType;
		String diagram = app.DrawingApp.getVerticalBars(maxRows, maxCols, bars, 
														color1, color2, color3);
		board = gui.BoardCell.getCharArray(diagram);
	}

}
