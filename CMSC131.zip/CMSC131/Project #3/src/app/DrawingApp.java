package app;

import java.util.Random;

public class DrawingApp {

	public static String getRectangle(int maxRows, int maxCols, char symbol) {
		String rectangle = "";
		int i, j;

		if (maxRows < 1 || maxCols < 1) {
			return null;
		}

		for (i = 0; i < maxRows; i++) {
			for (j = 0; j < maxCols; j++) {
				rectangle += symbol; //Each line of rectangle created
			}
			rectangle += "\n"; //The lines are added up 
		}

		return rectangle.trim();
	}

	public static String getFlag(int size, char color1, char color2, char color3) {
		String flag = "";
		int cols, i, j, k;

		if (size < 3) {
			return null;
		}
		cols = size * 5; //Not necessary, but less prone to sloppy errors.

		for (i = 1; i < size; i++) { //Increment of color2 quantity
			for (j = 1; j <= i; j++) {//Not nested with below. We want this one
				flag += color1;       //to go first and make beginnings of flag
			}
			for (k = 1; k <= cols - i; k++) {
				if (i == 1) { //Special case first row
					flag += color2;
				} else { //All other rows get color3 for remaining columns
					flag += color3;
				}
			}
			flag += "\n";
		} // Top of Flag

		for (i = 1; i < 3; i++) { //2 rows needed total
			for (j = 1; j <= size; j++) {
				flag += color1; //Color1 added 
			}
			for (k = 1; k <= cols - size; k++) {
				flag += color2;
			}
			flag += "\n";
		} // Middle of Flag

		for (i = size - 1; i > 0; i--) { //Decrement of color2 quantity
			for (j = 1; j <= i; j++) { //Not nested with below. We want this one
				flag += color1; 	   //to go first and make beginnings of flag
			}
			for (k = 1; k <= cols - i; k++) {
				if (i == 1) { //Last row special case
					flag += color2;
				} else { //All other rows get color3 for remaining columns
					flag += color3;
				}
			}
			flag += "\n";
		} // End of Flag

		return flag.trim();

	}

	public static String getHorizontalBars(int maxRows, int maxCols, int bars, char color1, char color2, char color3) {
		String horBars = "";
		int i, j, k, barSize, barCounter = 1;

		barSize = maxRows / bars;
		if (barSize < 1 || !isValidColor(color1) || !isValidColor(color2) || 
			!isValidColor(color3)) {
			return null;
		}
		for (i = 0; i < bars; i++) {
			for (j = 0; j < barSize; j++) {
				for (k = 0; k < maxCols; k++) {
					if (barCounter == 1) { //Determines color of bar
						horBars += color1;
					} else if (barCounter == 2) {
						horBars += color2;
					} else {
						horBars += color3;
					}
				}
				horBars += "\n";
			}
			barCounter++;
			if (barCounter == 4) {
				barCounter = 1; //Resets color of bar after 3 colors.
			}
		}

		return horBars.trim();
	}

	public static String getVerticalBars(int maxRows, int maxCols, int bars, char color1, char color2, char color3) {
		String verBars = "";
		int i, j, k, barSize, barCounter = 1;

		barSize = maxCols / bars;
		if (barSize < 1 || !isValidColor(color1) || !isValidColor(color2) || 
			!isValidColor(color3)) {
			return null;
		}
		for (i = 0; i < maxRows; i++) { //Difference with above in conditionals
			for (j = 0; j < bars; j++) {
				for (k = 0; k < barSize; k++) { 
					if (barCounter == 1) { //Same color determination as above
						verBars += color1;
					} else if (barCounter == 2) {
						verBars += color2;
					} else {
						verBars += color3;
					}
				}
				barCounter++;
				if (barCounter == 4) {
					barCounter = 1; //Same reset of color as above
				} //Really only difference with above is in conditionals.
			}
			verBars += "\n";
			barCounter = 1;
		}

		return verBars.trim();
	}

	public static char getRandomColor(Random random) {
		int randomNum;
		randomNum = random.nextInt(6); 

		if (randomNum == 0) { //Random number char assignment
			return 'R';
		} else if (randomNum == 1) {
			return 'G';
		} else if (randomNum == 2) {
			return 'B';
		} else if (randomNum == 3) {
			return 'Y';
		} else if (randomNum == 4) {
			return '*';
		} else if (randomNum == 5) {
			return '.';
		} else {
			return 'X'; //Extra scenario to catch errors
		}

	}

	private static boolean isValidColor(char color) {
		if (color == 'R' || color == 'G' || color == 'B' || color == 'Y' || 
			color == '*' || color == '.') {
			return true;
		} else {
			return false;
		}
	}
}