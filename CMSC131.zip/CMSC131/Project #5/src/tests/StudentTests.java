package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import photomanager.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	/*
	 * Each method in a JUnit StudentTest class represents a test. You can write
	 * code in a method of this class as you do in the main method of a driver. As
	 * you write your code, define methods in this class that test each of the
	 * methods you need to implement. When you run a method you can have
	 * System.out.println statements to see the results of your code. Using this
	 * approach is simpler than defining driver classes.
	 * 
	 * For this project you don't need to worry about adding assertions. If you
	 * don't add assertions, by default, every test will pass (so when you run your
	 * student tests you will see a green bar). We have left two examples of tests
	 * below so you can see how you can test your code.
	 * 
	 * You can run a single test by double-clicking on the method's name and
	 * selecting Run-->Run As-->JUnit Test. You can also double-click on the
	 * method's name and select the white triangle that is inside of a green circle
	 * (under Refactor).
	 * 
	 * Remember that each method representing a test must have @Test (this is called
	 * an annotation).
	 */

	/*
	 * Remove the following test and add your tests. We added this test to show the
	 * 
	 * @Test annotion.
	 */

	@Test
	public void ConstructorTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		System.out.println(mom);
	}

	@Test
	public void toStringTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		System.out.println(mom);
	}

	@Test
	public void getPhotoSourceTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		System.out.println(mom.getPhotoSource());
	}

	@Test
	public void getWidthTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		System.out.println(mom.getWidth());
	}

	@Test
	public void getHeightTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		System.out.println(mom.getHeight());
	}

	@Test
	public void getDateTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		System.out.println(mom.getDate());
	}

	@Test
	public void addCommentsTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		mom.addComments("Apple");
		System.out.println(mom.getComments());
	}

	@Test
	public void getCommentsTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		mom.addComments("Apple");
		System.out.println(mom.getComments());
	}

	@Test
	public void photoCopyConsTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "Nov12");
		Photo copy = new Photo(mom);
		copy.addComments("Cool");
		System.out.println("." + mom.getComments());
		System.out.println("." + copy.getComments());
	}

	@Test
	public void compareToTest() {
		Photo mom = new Photo("www.Jeff.org", 4, 3, "10/18/2020-17:10");
		Photo dad = new Photo("www.Jeff.org", 4, 3, "10/18/2020-17:20");
		System.out.println(mom.compareTo(dad));
	}

	@Test
	public void addPhotoTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.addPhoto("www.Jeff.com", 4, 6, "Nov8");
		System.out.println(kindle);
	}

	@Test
	public void toStringPMTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.addPhoto("www.Jeff.com", 4, 6, "Nov8");
		kindle.addPhoto("www.Jim.com", 4, 6, "Nov8");
		System.out.println(kindle);
	}

	@Test
	public void findPhotoTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.addPhoto("www.Jeff.com", 4, 6, "Nov8");
		System.out.println(kindle.findPhoto("www.Jeff.com"));
	}

	@Test
	public void addCommentPMTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.addPhoto("www.Jeff.com", 4, 6, "Nov8");
		kindle.addComment("www.Jeff.com", "My Mom is cool");
		kindle.addComment("www.Jeff.com", "My Mom is very cool");
		System.out.println(kindle.getComments("www.Jeff.com"));
	}

	@Test
	public void removeAllPhotosTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.addPhoto("www.Jeff.com", 4, 6, "Nov8");
		kindle.addPhoto("www.Jim.com", 10, 20, "Nov2");
		kindle.removeAllPhotos();
		System.out.println(kindle);
	}

	@Test
	public void removePhotoTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.addPhoto("www.Jeff.com", 4, 6, "Nov8");
		kindle.addPhoto("www.Jim.com", 10, 20, "Nov2");
		kindle.removePhoto("www.Jim.com");
		System.out.println(kindle);
	}

	@Test
	public void loadPhotosTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.loadPhotos("photoInfoToLoad.txt");
	}

	@Test
	public void sortPhotosTest() {
		PhotoManager kindle = new PhotoManager();
		kindle.addPhoto("www.Jim.org", 3, 4, "10/18/2020-17:30");
		kindle.addPhoto("www.Jeff.org", 4, 3, "10/18/2020-17:20");
		kindle.sortPhotosByDate();
		System.out.println(kindle);
	}

}