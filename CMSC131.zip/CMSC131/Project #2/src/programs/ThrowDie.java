package programs;

import java.util.Scanner;
import java.util.Random;

public class ThrowDie {

	public static void main(String[] args) {
		int n, seed, i, randomNumber;
		Scanner scanner = new Scanner(System.in);

		System.out.print("How many times to throw a die?: ");
		n = scanner.nextInt();
		System.out.print("Enter seed: ");
		seed = scanner.nextInt();
		Random random = new Random(seed); //Random object MUST be out of loop
										  //otherwise only first number used
		for (i = 1; i <= n; i++) {
			randomNumber = 1 + random.nextInt(6);
			System.out.println("Throw #" + i);
			dieGenerator(randomNumber); //Other method referenced for efficiency
		}

		scanner.close();
	}

	public static void dieGenerator(int x) {
		String die = ""; //Very "dumb" method. We know all 6 possible results,
		if (x == 1) {    //so simple if else statements are satisfactory.
			die = "...\n.0.\n...";
		} else if (x == 2) {
			die = "0..\n...\n..0";
		} else if (x == 3) {
			die = "0..\n.0.\n..0";
		} else if (x == 4) {
			die = "0.0\n...\n0.0";
		} else if (x == 5) {
			die = "0.0\n.0.\n0.0";
		} else if (x == 6) {
			die = "0.0\n0.0\n0.0";
		}
		System.out.println(die);
		return;
	}

}
