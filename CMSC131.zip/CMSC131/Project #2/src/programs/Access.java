package programs;

import java.util.Scanner;

public class Access {

	public static void main(String[] args) {
		int number = 0, counter = 0;
		String password = "";
		Scanner scanner = new Scanner(System.in);

		do {
			System.out.print("Enter password: ");
			password = scanner.next();
			if (password.equals("quit")) { // Special case of quit addressed
				System.out.println("Access Denied");
				return;
			} else {
				System.out.print("Enter number: ");
				number = scanner.nextInt();
				counter++; // Tracks number of user attempts

				if (number != 1847 || !password.equals("terps")) {
					System.out.println("Wrong credentials");
					if (counter == 3) { // Wrong user answer, 2 possibilities
						System.out.println("Access Denied");
						return;
					}
				} else {
					System.out.println("Access Granted");
				}
			}
		} while (number != 1847 || !password.equals("terps"));
// Terminates when both conditions are true, in special quit case or after 3 try
		scanner.close();
	}
}
