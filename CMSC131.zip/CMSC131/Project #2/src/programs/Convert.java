package programs;

import java.util.Scanner;

public class Convert {
	public static void main(String[] args) {
		int decimal, remainder = 0;
		String octal = "";

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter decimal number: ");
		decimal = scanner.nextInt();

		if (decimal > 7) {
			do { 					//do while not ~really~ needed but useful
				remainder = decimal % 8; 
				decimal /= 8;
				octal = remainder + octal; //adds remainders from bottom to top
			} while (decimal > 7);

			if (decimal % 8 != 0) { //deals with any remainder after decimal<8
				remainder = decimal % 8; 
				octal = remainder + octal; 

			}
		} else {
			octal += decimal;
		}

		System.out.println("Octal value: " + octal);

		scanner.close();
	}
}
