package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import programs.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
    @Test
    public void getLengthLargestRowTest() {
    	int[][] data = {{1,2,3,4,5} , {2,3} , {4}};
    	System.out.println(Utilities.getLengthLargestRow(data));
    }
    
    @Test
    public void duplicateAndFillTest() {
    	int[] data = {1,2,3,4,5};
    	System.out.println(Utilities.duplicateAndFill(data, 10, 1));
    }
    
    @Test
    public void replaceVowelsWithTest() {
    	String s = "apples";
    	System.out.println(RecursionProblem.replaceVowelsWith(s, "m"));
    }
}