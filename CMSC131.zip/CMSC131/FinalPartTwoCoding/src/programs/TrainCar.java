package programs;

import java.util.ArrayList;

public class TrainCar {
	private int tons;
	private ArrayList<String> trainCarItems;

	public TrainCar() {
		tons = 0;
		trainCarItems = new ArrayList<String>();
	}

	public TrainCar(TrainCar trainCar) {
		this.tons = trainCar.tons;
		this.trainCarItems = new ArrayList<String>();
		int i;
		
		for(i = 0; i < trainCar.trainCarItems.size(); i++) {
			this.trainCarItems.add(new String(trainCar.trainCarItems.get(i)));
		}
		
	}

	public TrainCar addItem(String itemsName, int tons) {
		if(itemsName == null || tons <= 0) {
			throw new IllegalArgumentException("STOP");
		}
		String adding = itemsName;
		adding = adding + Integer.toString(tons);
		
		this.trainCarItems.add(adding);
		this.tons += tons;
		
		return this;
	}

	public String getItems() {
		return this.trainCarItems.toString();
	}

	public int getTons() {
		return this.tons;
	}

	/* Provided: Please do not modify */
	public String toString() {
		return "Tons: " + tons + ", Items: " + trainCarItems;
	}

	public boolean equals(Object obj) {
		TrainCar tc = (TrainCar) obj;
		if(this.toString().equals(tc.toString())) {
			return true;
		}else {
			return false;
		}
	}
}