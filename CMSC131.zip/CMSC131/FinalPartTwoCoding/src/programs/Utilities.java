package programs;

public class Utilities {
	public static int getLengthLargestRow(int[][] data) {
		int largestLength, i;
		
		if(data == null) {
			throw new IllegalArgumentException("STOP");
		}

		if(data[0] == null) {
			largestLength = 0;
		}else {
			largestLength = data[0].length;
		}
			
		for(i = 1; i < data.length; i++) {
			if(data[i] != null && data[i].length > largestLength) {
				largestLength = data[i].length;
			}
		}
		return largestLength;		
	}

	public static int[] duplicateAndFill(int[] data, int newLength, int filler) {
		if(data == null || newLength < data.length) {
			throw new IllegalArgumentException("STOP");
		}
		
		int[] newData = new int[newLength];
		int i;
		
		for(i = 0; i < data.length; i++) {
			newData[i] = data[i];
		}
		
		for(i = data.length; i < newLength; i++) {
			newData[i] = filler;
		}
		
		return newData;
	}

	public static int[][] getNonRaggedArray(int[][] data, int filler) {
		if(data == null) {
			throw new IllegalArgumentException("STOP");
		}
		int[][] newData = new int[data.length][];
		int newLength = getLengthLargestRow(data), i;
		
		for(i = 0; i < newData.length; i++) {
			if(data[i] != null) {
				newData[i] = duplicateAndFill(data[i], newLength, filler);				
			}else {
				newData[i] = duplicateAndFill(new int[0], newLength, filler);
			}
		}
		return newData;
	}
}
