package programs;

/* Provided: Please do not modify 
 * 
 * We have provided this class; do not modify it.
 * It is used by the SampleDriverTrain.java driver
 * to show the results of the getNumberOfTrainCars
 * method. 
 */
public class Truck implements CargoVehicle {
	private StringBuffer items;
	private int tons;

	public Truck(StringBuffer items, int tons) {
		this.items = new StringBuffer(items);
		this.tons = tons;
	}

	public int getTons() {
		return tons;
	}

	public StringBuffer getItems() {
		return new StringBuffer(items);
	}

	public String toString() {
		return "Truck [items=" + items + ", tons=" + tons + "]";
	}
}
