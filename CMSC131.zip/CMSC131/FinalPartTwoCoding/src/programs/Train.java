package programs;

import java.util.ArrayList;

public class Train implements CargoVehicle, Comparable<Train> {
	private String name;
	private int numberOfTrainCars;
	private TrainCar[] allTrainCars;

	public Train(String name, int maxTrainCars) {
		this.name = name;
		numberOfTrainCars = 0;
		allTrainCars = new TrainCar[maxTrainCars];
	}

	public boolean addTrainCar() {
		TrainCar trainCar = new TrainCar();
		int i;
		
		for(i = 0; i < allTrainCars.length; i++) {
			if(allTrainCars[i] == null) {
				allTrainCars[i] = trainCar;
				numberOfTrainCars++;
				return true;
			}
		}
		return false;
	}

	public boolean addItemToCar(String itemsName, int tons, int trainCarIndex) {
		if(trainCarIndex < 0 || trainCarIndex >= numberOfTrainCars || itemsName == null || tons <= 0) {
			return false;
		}
		
		allTrainCars[trainCarIndex].addItem(itemsName, tons);
		return true;
	}

	/* Provided: Please do not modify */
	public String toString() {
		String answer = "";

		answer += "Name: " + name + "\n";
		answer += "NumberOfTrainCars: " + numberOfTrainCars + "\n";
		answer += "TrainCars:" + "\n";
		for (int i = 0; i < numberOfTrainCars; i++) {
			answer += allTrainCars[i] + "\n";
		}

		return answer;
	}

	/* Provided: Please do not modify */
	public String getName() {
		return name;
	}

	/* Provided: Please do not modify */
	public int getNumberOfTrainCars() {
		return numberOfTrainCars;
	}

	public int getTons() {
		int i, totalTons = 0;
		
		for(i = 0; i < numberOfTrainCars; i++) {
			totalTons+= allTrainCars[i].getTons();
		}
		
		return totalTons;
	}

	public StringBuffer getItems() {
		int i;
		StringBuffer totalItems = new StringBuffer();
		
		for(i = 0; i < numberOfTrainCars; i++) {
			totalItems.append(allTrainCars[i].getItems());
		}
		
		return totalItems;
	}

	public int compareTo(Train train) {
		if(this.getTons() > train.getTons()) {
			return -1;
		}else if(this.getTons() < train.getTons()){
			return 1;
		}else {
			return 0;
		}
	}

	public Train getTrainWithCars(String name, int[] trainCarIndices) {
		Train copy = new Train(name, trainCarIndices.length);
		copy.numberOfTrainCars = trainCarIndices.length;
		int i;
		
		for(i = 0; i < trainCarIndices.length; i++) {
			copy.allTrainCars[i] = new TrainCar(this.allTrainCars[trainCarIndices[i]]);
		}
		
		return copy;
		
	}

	public static int getNumberOfTrainCars(ArrayList<CargoVehicle> vehicles) {
		int i, totalTrains = 0;
		
		for(i = 0; i < vehicles.size(); i++) {
			if(vehicles.get(i) instanceof Train) {
				Train train = (Train)vehicles.get(i);
				totalTrains += train.getNumberOfTrainCars();
			}
		}
		return totalTrains;
	}
}