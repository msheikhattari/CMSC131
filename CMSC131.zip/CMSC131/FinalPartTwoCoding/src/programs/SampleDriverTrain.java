package programs;

import java.util.ArrayList;

/* 
 * You can use this code to write your own tests  
 */
public class SampleDriverTrain {

	public static void main(String[] args) {
		String answer = "", name = "MainTrain";
		int maxTrainCars = 4;

		answer += "**** Train ****\n";
		Train train1 = new Train(name, maxTrainCars);
		train1.addTrainCar();
		train1.addTrainCar();
		train1.addTrainCar();
		train1.addTrainCar();
		answer += "After adding two cars" + "\n";
		answer += train1 + "\n";

		train1.addItemToCar("Oranges", 20, 1); // added to second TrainCar
		train1.addItemToCar("Cameras", 50, 0); // added to first TrainCar
		train1.addItemToCar("Laptops", 8, 0); // added to first TrainCar
		train1.addItemToCar("Recorders", 10, 3); // added to third TrainCar

		answer += "After adding items to cars" + "\n";
		answer += train1 + "\n";

		answer += "Some get methods\n";
		answer += "getTons: " + train1.getTons() + "\n";
		answer += "getItems: " + train1.getItems() + "\n\n";

		Train train2 = new Train("Express", 10);
		train2.addTrainCar();
		train2.addTrainCar();
		train2.addItemToCar("Doors", 40, 0);
		answer += "Second Train\n";
		answer += train2 + "\n";

		answer += "Method compareTo: " + (train1.compareTo(train2) < 0) + "\n\n";

		answer += "Method: getTrainWithCars\n";
		int[] indicesOfCarsWeWant = { 0, 3 };
		Train resultTrain = train1.getTrainWithCars("SpecialTrain", indicesOfCarsWeWant);
		answer += resultTrain + "\n";

		answer += "Method: getNumberOfTrainCars\n";
		Truck truck1 = new Truck(new StringBuffer("Bikes"), 10);
		ArrayList<CargoVehicle> vehicles = new ArrayList<CargoVehicle>();
		vehicles.add(train1);
		vehicles.add(truck1);
		vehicles.add(train2);
		answer += "Train cars: " + Train.getNumberOfTrainCars(vehicles);

		System.out.println(answer);
	}
}