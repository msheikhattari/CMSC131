package programs;

public class RecursionProblem {
	public static String replaceVowelsWith(String str, String replacement) {
		if(str == null || replacement == null) {
			throw new IllegalArgumentException("STOP");
		}
		
		if(str.length() == 1) {
			if(Character.toLowerCase(str.charAt(0)) == 'a' || 
			   Character.toLowerCase(str.charAt(0)) == 'e' || 
			   Character.toLowerCase(str.charAt(0)) == 'i' ||
			   Character.toLowerCase(str.charAt(0)) == 'o' ||
			   Character.toLowerCase(str.charAt(0)) == 'u') {
				return replacement;
			}else {
				return Character.toString(Character.toLowerCase(str.charAt(0)));
			}
		}
		if(Character.toLowerCase(str.charAt(0)) == 'a' || 
		   Character.toLowerCase(str.charAt(0)) == 'e' || 
		   Character.toLowerCase(str.charAt(0)) == 'i' ||
		   Character.toLowerCase(str.charAt(0)) == 'o' ||
		   Character.toLowerCase(str.charAt(0)) == 'u') {
			return replacement + replaceVowelsWith(str.substring(1), replacement);
		}else {
			return Character.toString(Character.toLowerCase(str.charAt(0))) + 
				   replaceVowelsWith(str.substring(1), replacement);
		}
	}

	public static int setToPositive(int[] array) {
		if(array == null) {
			throw new IllegalArgumentException("STOP");
		}
		
		return cleverSetToPositive(array, 0);
	}
	
	private static int cleverSetToPositive(int[] array, int counter) {
		if(counter == array.length) {
			return 0;
		}else if(array[counter] < 0) {
			array[counter] = Math.abs(array[counter]);
			counter = counter + 1;
			return 1 + cleverSetToPositive(array, counter);
		}else {
			counter = counter + 1;
			return cleverSetToPositive(array,counter);
		}
	}
}
