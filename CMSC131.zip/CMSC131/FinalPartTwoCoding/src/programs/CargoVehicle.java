package programs;

/* Provided: Please do not modify 
 */
public interface CargoVehicle {
	public int getTons();
	public StringBuffer getItems();
}
