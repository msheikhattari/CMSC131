package programs;

import java.util.Arrays;
import tests.TestingSupport;

/* 
 * You can use this code to write your own tests  
 */

public class SampleDriverUtilities {
	public static void main(String[] args) {
		String answer = "";

		answer += "**** Utilities.getLengthLargestRow ****\n";
		int[][] twoDimArray = { { 30 }, { 10, 6, 9, 2, 89 }, { 77, 20, 2 } };
		answer += "Array\n";
		answer += TestingSupport.getStringForTwoDimIntArray(twoDimArray) + "\n";
		int maxLength = Utilities.getLengthLargestRow(twoDimArray);
		answer += "MaxLength: " + maxLength + "\n\n";

		answer += "**** Utilities.duplicateAndFill ****\n";
		int[] oneDimArray = { 30, 4, 6, 8 };
		int newLength = 9, filler = 9;
		int[] result = Utilities.duplicateAndFill(oneDimArray, newLength, filler);
		answer += "Original Array: " + Arrays.toString(oneDimArray) + "\n";
		answer += "Result Array: " + Arrays.toString(result) + "\n\n";

		answer += "**** Utilities.getNonRaggedArray ****\n";
		filler = 4;
		int[][] nonRaggedArray = Utilities.getNonRaggedArray(twoDimArray, filler);
		answer += "Original Array\n";
		answer += TestingSupport.getStringForTwoDimIntArray(twoDimArray) + "\n\n";
		answer += "Result Array\n";
		answer += TestingSupport.getStringForTwoDimIntArray(nonRaggedArray);

		System.out.println(answer);
	}
}